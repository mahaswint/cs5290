# Report LaTeX source

Upload the contents of this ZIP to Overleaf. Select report.tex as the main file and use pdfLaTeX. Alternatively run `tectonic report.tex` or `latexmk -pdf report.tex`.

The main file includes all report text, both tables, equations, references and the TikZ baseline diagram. The Group-11 author block and artifacts/ layout follow the uploaded current source. The bundled IEEEtran.cls and all five results plots are in artifacts/; keep that directory next to report.tex. Figure and table captions define their abbreviations locally. The report uses the standard IEEE conference layout and is seven pages.

The complete data and plot-generation scripts are in the accompanying latex-source.zip and source-code.zip packages.
