# Complete IEEE LaTeX project

Upload this directory to Overleaf and select report.tex as the main document, with pdfLaTeX. Alternatively run `tectonic report.tex` or `latexmk -pdf report.tex`. The requested template uses IEEEtran conference mode, standard margins and two columns. IEEEtran.cls and all external figures/tables are included. The main report preserves the Group-11 author block and inline tables from the uploaded source, with its supporting files in artifacts/.

Select baseline-results.tex or contribution-results.tex for the separate results documents. Those extracts use one column for wide tables. All figures are vector PDFs, with editable SVG and 400 dpi PNG exports. No figure downloads are needed during compilation.

Optional graph regeneration: install tools/requirements.txt in a Python environment and run `python tools/figures.py` from this directory. Its inputs are included in data/history/ and evidence/final-98-runs.csv. Graph values retain full CSV precision; report tables round for display. data/README.md defines units and scopes. The main report keeps the results in its Evaluation section.
